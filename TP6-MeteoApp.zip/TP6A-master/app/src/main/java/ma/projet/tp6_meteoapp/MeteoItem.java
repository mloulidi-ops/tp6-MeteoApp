package ma.projet.tp6_meteoapp;

public class MeteoItem {
    public int tempMax;
    public int tempMin;
    public int pression;
    public int humidite;
    public String image; // Stores the icon code (e.g., "01d")
    public String date;
}